// Load_Disp.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <cv.h>
#include <highgui.h>
#include <cxcore.h>
#include "C_Image.h"


void imageshow(char *WinName,IplImage *img);


int _tmain(int argc, _TCHAR* argv[])
{
	IplImage *img;
	CvSize size;

	C_Image image;
	if(!image.ReadTiff("c:\\test.tif"))
		return -1;
// -------------------------------------------------------------------------------------------------		
// W TYM MIEJSCU WSTAWIAMY W�ASNY KOD
// PAMI�TAMY �E PISZEMY FUNKCJ� KT�RA POBIERA I ZWRACA WSKA�NIKI DO KLASY C_Image TAK JAK BY�O POPRZEDNIO USTALANE
// Mamy do dyspozycji obiekt klasy C_Image zawieraj�cy podstawowe funkcje od obs�ugi obrazka oraz sam obrazek - szczeg�y w pliku C_Image.h

// Przyk�ady:	
/*	Wczytanie tiffa
	C_Image image;
	image.ReadTiff("c:\\test.tif");

// nagranie do pliku - format bin - do obs�ugi w matlabie
	image.saveimage2matlab("c:\\test.bin");		
	
// pobranie pixela
	unsigned int pixel;
	image.GetPixel(100, 800, pixel);

// ustawienie pixela
	image.SetPixel(100, 800, 10);

// tworzenie nowego obrazka (nie tiffa)
	C_Image nowy_obraz();
	unsigned int x_res, y_res;
	x_res = 600;
	y_res = 800;
	nowy_obraz.AllocateData(y_res,x_res);

// kopiowanie obrazk�w
	C_Image destination;		// tu b�dzie kopia
	image.CloneImage(&destination);		// skopiowanie obrazka image do destination
	

*/


//	image.saveimage2matlab("c:\\test1.bin");	

// ----- Wy�wietlanie za pomoc� CV ----------------------------------------------
	size.height = image._rows;
	size.width = image._cols;
	img = cvCreateImage(size, IPL_DEPTH_16U, 1);
	img->imageData = image.ReturnIPLBuffor();
	imageshow("Image",img);
	cvWaitKey();
	
//------- Sprz�tanie -----------------------------------------------------------	
	cvDestroyWindow("Image");
	cvReleaseImage(&img);
	return 0;
}

void imageshow(char *WinName,IplImage *img)
{
	cvNamedWindow(WinName,1);
	cvShowImage(WinName,img);
}